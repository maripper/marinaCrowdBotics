// rename this file from demo.env.js to env.js
// when you have generated your API key from NewsAPI.org
// place the API key below

export const API_KEY = 'XXXXXXXX';
