import React, { Component } from 'react';

import News from './src/components/News';

export default class App extends Component {
	render() {
		return <News />;
	}
}
